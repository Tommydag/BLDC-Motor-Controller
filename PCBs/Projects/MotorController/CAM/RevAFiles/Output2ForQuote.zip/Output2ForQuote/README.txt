project: motorcon

Part Number 6 
Rev A

File Contents:
motorcon.GBL-Bottom copper
motorcon.GBO-Bottom Silkscreen
motorcon.GBS-Bottom Soldermask
motorcon.GTL-Top copper
motorcon.GTO-Top Silkscreen
motorcon.GTS-Top Soldermask
motorcon.L2- Copper for layer 2
motorcon.L3- Copper for layer 3
motorcon.TAP- NC drill file
motorcon.DWG- Fab gerber file with dimensions and fab notes
Readme.txt-This document

Contact Information: 
Tom D'Agostino
Phone:6518959975
Email:dagosttv@rose-hulman.edu